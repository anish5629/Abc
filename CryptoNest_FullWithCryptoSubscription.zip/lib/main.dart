import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(CryptoNestApp());
}

class CryptoNestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CryptoNest',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(),
    );
  }
}
