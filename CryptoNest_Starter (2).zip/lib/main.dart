
import 'package:flutter/material.dart';

void main() {
  runApp(CryptoNestApp());
}

class CryptoNestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CryptoNest',
      home: Scaffold(
        appBar: AppBar(title: Text('CryptoNest')),
        body: Center(
          child: Text('Welcome to CryptoNest - Crypto Subscription App'),
        ),
      ),
    );
  }
}
